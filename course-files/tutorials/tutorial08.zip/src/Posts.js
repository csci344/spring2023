import React from 'react';

export default function Posts() { 
   
    return (
        <div>Your posts here...</div>
    );     
}
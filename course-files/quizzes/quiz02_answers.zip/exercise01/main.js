function photo1() {
    document.querySelector('img').src = "images/fox.jpg";
    document.querySelector('p').innerText = "Fox";
}

function photo2() {
    document.querySelector('img').src = "images/lion.jpg";
    document.querySelector('p').innerText = "Lion";
}

function photo3() {
    document.querySelector('img').src = "images/tiger.png";
    document.querySelector('p').innerText = "Tiger";
}


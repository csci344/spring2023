const toggleFall = () => {
    document.querySelector('h1').innerText = "Fall in Asheville";
    document.querySelector('body').className = "fall";
}

const toggleWinter = () => {
    document.querySelector('h1').innerText = "Winter in Asheville";
    document.querySelector('body').className = "winter";
}

const toggleSpring = () => {
    document.querySelector('h1').innerText = "Spring in Asheville";
    document.querySelector('body').className = "spring";
}